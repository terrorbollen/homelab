{{/*
Expand the name of the chart.
*/}}
{{- define "rollout-operator.name" -}}
{{- default (include "rollout-operator.chartName" .) .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "rollout-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default (include "rollout-operator.chartName" .) .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Recalculate the chart name, because it may be sub-chart included as rollout_operator,
and _ is not valid in resource names.
*/}}
{{- define "rollout-operator.chartName" -}}
{{- print .Chart.Name | replace "_" "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "rollout-operator.chart" -}}
{{- printf "%s-%s" (include "rollout-operator.chartName" .) .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "rollout-operator.labels" -}}
helm.sh/chart: {{ include "rollout-operator.chart" . }}
{{ include "rollout-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.global.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Pod labels: the common labels without helm.sh/chart. That label carries the chart version, so
including it in the pod template recreates the pod on every chart release even when neither the
image nor the configuration changed. app.kubernetes.io/version stays, since it is .Chart.AppVersion
and so tracks the operator image rather than chart metadata.
*/}}
{{- define "rollout-operator.podLabels" -}}
{{- $common := omit (include "rollout-operator.labels" . | fromYaml) "helm.sh/chart" -}}
{{- /* Precedence: selector labels, then podLabels, then common labels. The selector labels must win
so that global.commonLabels cannot make the pod template diverge from spec.selector.matchLabels. */ -}}
{{- merge (include "rollout-operator.selectorLabels" . | fromYaml) (deepCopy (.Values.podLabels | default dict)) $common | toYaml -}}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "rollout-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "rollout-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "rollout-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "rollout-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}


{{- define "cli.labels" -}}
{{- $list := list -}}
{{- range $k, $v := ( include "rollout-operator.selectorLabels" . | fromYaml ) -}}
{{- $list = append $list (printf "%s=%s" $k $v) -}}
{{- end -}}
{{ join "," $list }}
{{- end -}}

{{/*
Create the image name
*/}}
{{- define "rollout-operator.imageName" -}}
{{- $imageTag := (.Values.image.tag | default .Chart.AppVersion) }}
{{- if .Values.image.registry }}
{{- (printf "%s/%s:%s" .Values.image.registry .Values.image.repository $imageTag) }}
{{- else }}
{{- (printf "%s:%s" .Values.image.repository $imageTag) }}
{{- end -}}
{{- end -}}
